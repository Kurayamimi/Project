$(document).ready(function() {
    $('#submit-button1').on('submit', function(e) {
       e.preventDefault(); // prevent page refresh
       // add your code to process the form data here
    });
   });