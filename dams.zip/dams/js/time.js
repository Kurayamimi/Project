function validateTime() {
    var time = document.getElementById("time").value;

    var disabledTimestamps = ["00:00", "01:00", "02:00", "03:00", "04:00", "05:00", "06:00", "07:00", "08:00", "09:00", "21:00", "22:00", "23:00", "24:00"];

    if (disabledTimestamps.includes(time)) {
        alert("Invalid time selected. Please select a time between 10:00 AM and 08:00 PM");
        document.getElementById("time").value = "10:00";
    }
}