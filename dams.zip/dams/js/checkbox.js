$('#check').click(function() {
    if ($(this).is(':checked')) {
      $('#submit-button1').removeAttr('disabled');
    } else {
      $('#submit-button1').attr('disabled', 'disabled');
    }
  });