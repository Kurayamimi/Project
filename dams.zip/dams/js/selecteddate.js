function sendValue() {
    var selectedDate = document.getElementById('date').value;
    console.log(selectedDate);
    fetch('?', {
        method: 'POST',
        body: 'selectedDate=' + selectedDate
    })
    .then(response => response.text())
    .then(data => {
        console.log(data); // Output the response from the PHP script
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}

$(function(){
    var dtToday = new Date();

    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
    day = '0' + day.toString();
    var maxDate = year + '-' + month + '-' + day;
    $('#date').attr('min', maxDate);
});