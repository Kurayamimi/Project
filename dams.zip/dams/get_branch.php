<?php
include('primax/includes/dbconnection.php');
if(!empty($_POST["b_id"])) 
{
$bid=$_POST["b_id"];
$sql=$dbh->prepare("SELECT * FROM tblbranch WHERE BranchName=:bid");
$sql->execute(array(':bid' => $bid));	
?>
<option value="">Select Branch</option>
<?php
while($row =$sql->fetch())
{
?>
<option value="<?php echo $row["ID"]; ?>"><?php echo $row["BranchName"]; ?></option>
<?php
}
}
?>