<?php
session_start();
include('primax/includes/dbconnection.php');
?>
<!doctype html>
<html lang="en">
    <head>
        <title>PRIMAX SELF PHOTO STUDIO</title>
        <!-- CSS FILES -->        
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-icons.css" rel="stylesheet">
        <link href="css/owl.carousel.min.css" rel="stylesheet">
        <link href="css/owl.theme.default.min.css" rel="stylesheet">
        <link href="css/templatemo-medic-care.css" rel="stylesheet">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    </head> 
    <body id="top">
        <main>
            <?php include_once('includes/header.php');?>
                  <div class="container">
                  <h2 class="text-center mb-lg-3 mb-2">Location</h2>
                    <div class="row">
                    <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
                      <div class="carousel-indicators">
                        <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
                      </div>
                      <div class="carousel-inner">
                        <div class="carousel-item active" data-bs-interval="10000">
                          <img style="filter: brightness(50%);" src="images/slider/loc1.png" class="d-block w-100" alt="...">
                          <div class="carousel-caption d-none d-md-block">
                            <h5 style="color: #FFFFFF">Meycauayan Branch</h5>
                          </div>
                        </div>
                        <div class="carousel-item" data-bs-interval="2000">
                          <img style="filter: brightness(50%);" src="images/slider/loc2.png" class="d-block w-100" alt="...">
                          <div class="carousel-caption d-none d-md-block">
                            <h5 style="color: #FFFFFF">Bocaue Branch</h5>
                          </div>
                        </div>
                        <div class="carousel-item">
                          <img style="filter: brightness(50%);" src="images/slider/loc3.png" class="d-block w-100" alt="...">
                          <div class="carousel-caption d-none d-md-block">
                            <h5 style="color: #FFFFFF">Valenzuela Branch</h5>
                          </div>
                        </div>
                      </div>
                      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                      </button>
                      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                      </button>
                    </div>
                  </div>
                  </div>
                </div>
        </main>
        <?php include_once('includes/footer.php');?>
        <!-- JAVASCRIPT FILES -->
        <script src="js/jquery.min.js"></script>
        <script src="js/time.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/scrollspy.min.js"></script>
        <script src="js/custom.js"></script>
    </body>
</html>