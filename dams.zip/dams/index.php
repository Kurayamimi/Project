<?php
session_start();
//error_reporting(0);
include('primax/includes/dbconnection.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

if(isset($_POST['submit-button1']))
{

$name=$_POST['name'];
$mobnum=$_POST['phone'];
$email=$_POST['email'];
$appdate=$_POST['date'];
list($year, $month, $day) = explode('-', $appdate);
$aaptime=$_POST['time'];
$packages=$_POST['packages'];
$branch=$_POST['branch'];
$payment=$_POST['payment'];
$aptnumber1  = $year . $month . $day;
$aptnumber = $aptnumber1 . $aaptime;
$cdate=date('Y-m-d');


$mail = new PHPMailer(true);
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'primax02023@gmail.com';
$mail->Password = 'tacquqcmbnpaegzt';
$mail->SMTPSecure = 'ssl';
$mail->Port = 465;
$mail->setFrom('primax02023@gmail.com');
$mail->addAddress($email);
$mail->isHTML(true);
$mail->Subject = "Dear " . $name . ",";
$mail->Body = "Your appointment number is " . $aptnumber . ".

We will take note of the specifics of the appointment and will contact you right away for the status of your appointment. Please do not hesitate to let us know in advance if you have any special demands or preferences.

Thank you for choosing Primax Self Photo Studio. We look forward to welcoming you to our studio and creating beautiful memories together.

Best regards,

Primax Self Photo Studio
";

if($appdate<=$cdate){    
    echo "<script>alert('Date must be higher than the current date');</script>";
}else {
$sql="insert into tblappointment(AppointmentNumber,Name,MobileNumber,Email,AppointmentDate,AppointmentTime,AppointmentTimeName,Packages,Branch,Method)values(:aptnumber,:name,:mobnum,:email,:appdate,:aaptime,:aaptime1,:packages,:branch,:payment);";
$query=$dbh->prepare($sql);
$query->bindParam(':aptnumber',$aptnumber,PDO::PARAM_STR);
$query->bindParam(':name',$name,PDO::PARAM_STR);
$query->bindParam(':mobnum',$mobnum,PDO::PARAM_STR);
$query->bindParam(':email',$email,PDO::PARAM_STR);
$query->bindParam(':branch',$branch,PDO::PARAM_STR);
$query->bindParam(':appdate',$appdate,PDO::PARAM_STR);
$query->bindParam(':aaptime',$aaptime,PDO::PARAM_STR);
$query->bindParam(':aaptime1',$aaptime1,PDO::PARAM_STR);
$query->bindParam(':packages',$packages,PDO::PARAM_STR);
$query->bindParam(':payment',$payment,PDO::PARAM_STR);
$query->execute();
$LastInsertId=$dbh->lastInsertId();
    if ($LastInsertId>0) {
        echo "<script>alert('Your Appointment Request Has Been Send. We Will Contact You Soon');</script>";
        $mail->send();
    }
    else
    {
        echo "Something Went Wrong. Please try again";
    }
}
}
?>
<!doctype html>
<html lang="en">
    <head>
        <title>PRIMAX SELF PHOTO STUDIO</title>
        <!-- CSS FILES -->        
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-icons.css" rel="stylesheet">
        <link href="css/owl.carousel.min.css" rel="stylesheet">
        <link href="css/owl.theme.default.min.css" rel="stylesheet">
        <link href="css/templatemo-medic-care.css" rel="stylesheet">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    </head> 
    <body id="top">
        <main>
            <?php include_once('includes/header.php');?>
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div id="myCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel">
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <img src="images/slider/pic1.jpg" class="img-fluid" alt="">
                                    </div>

                                    <div class="carousel-item">
                                        <img src="images/slider/pic2.jpg" class="img-fluid" alt="">
                                    </div>

                                    <div class="carousel-item">
                                        <img src="images/slider/pic3.jpg" class="img-fluid" alt="">
                                    </div>

                                    <div class="carousel-item">
                                        <img src="images/slider/pic4.jpg" class="img-fluid" alt="">
                                    </div>

                                    <div class="carousel-item">
                                        <img src="images/slider/pic5.jpg" class="img-fluid" alt="">
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>  
            <section class="section-padding" id="about">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-12">
                            <?php
                                $sql="SELECT * from tblpage where PageType='aboutus'";
                                $query = $dbh -> prepare($sql);
                                $query->execute();
                                $results=$query->fetchAll(PDO::FETCH_OBJ);
                                $cnt=1;
                                if($query->rowCount() > 0)
                                {
                                foreach($results as $row)
                                {?>
                            <h2 class="mb-lg-3 mb-3"><?php  echo htmlentities($row->PageTitle);?></h2>
                            <p><?php  echo ($row->PageDescription);?>.</p>
                            <?php $cnt=$cnt+1;}}?>
                        </div>
                        <div class="col-lg-4 col-md-5 col-12 mx-auto">
                            <div class="featured-circle bg-white shadow-lg d-flex justify-content-center align-items-center">
                                <p class="featured-text"><span class="featured-number" style="color: black">1</span><br> Year<br> Anniversary</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="gallery">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-6 ps-0">
                            <img src="images/gallery/pic1.jpg" class="img-fluid galleryImage" alt="get a vaccine" title="get a vaccine for yourself">
                        </div>

                        <div class="col-lg-6 col-6 pe-0">
                            <img src="images/gallery/pic2.jpg" class="img-fluid galleryImage" alt="wear a mask" title="wear a mask to protect yourself">
                        </div>
                    </div>
                </div>
            </section>
            <section class="section-padding" id="card-packages">
                <div class="container">
                <h2 class="text-center mb-lg-3 mb-2">List of Packages</h2>
                    <div class="row row-cols-2 row-cols-md-4 g-4">
                        <div class="col">
                            <div class="card">
                            <div class="card-body">
                            <?php
                                $sql="SELECT * from tblpackages where ID='1'";
                                $query = $dbh -> prepare($sql);
                                $query->execute();
                                $results=$query->fetchAll(PDO::FETCH_OBJ);
                                $cnt=1;
                                if($query->rowCount() > 0)
                                {
                                foreach($results as $row)
                                {?>
                                <h5 class="card-title"><?php  echo htmlentities($row->PackageName);?></h5>
                                <p class="card-text"><?php  echo htmlentities($row->Details);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->ShootTime);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->SelectionTime);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->BackdropChoice);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->PrintedPhoto);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->Copies);?></p>
                            <?php $cnt=$cnt+1;}}?>
                            </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card">
                            <div class="card-body">
                            <?php
                                $sql="SELECT * from tblpackages where ID='2'";
                                $query = $dbh -> prepare($sql);
                                $query->execute();
                                $results=$query->fetchAll(PDO::FETCH_OBJ);
                                $cnt=1;
                                if($query->rowCount() > 0)
                                {
                                foreach($results as $row)
                                {?>
                                <h5 class="card-title"><?php  echo htmlentities($row->PackageName);?></h5>
                                <p class="card-text"><?php  echo htmlentities($row->Details);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->ShootTime);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->SelectionTime);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->BackdropChoice);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->PrintedPhoto);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->Copies);?></p>
                                <br>
                                <br>
                            <?php $cnt=$cnt+1;}}?>
                            </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card">
                            <div class="card-body">
                            <?php
                                $sql="SELECT * from tblpackages where ID='3'";
                                $query = $dbh -> prepare($sql);
                                $query->execute();
                                $results=$query->fetchAll(PDO::FETCH_OBJ);
                                $cnt=1;
                                if($query->rowCount() > 0)
                                {
                                foreach($results as $row)
                                {?>
                                <h5 class="card-title"><?php  echo htmlentities($row->PackageName);?></h5>
                                <p class="card-text"><?php  echo htmlentities($row->Details);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->ShootTime);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->SelectionTime);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->BackdropChoice);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->PrintedPhoto);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->Copies);?></p>
                                <br>
                                <br>
                            <?php $cnt=$cnt+1;}}?>
                            </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card">
                            <div class="card-body">
                            <?php
                                $sql="SELECT * from tblpackages where ID='4'";
                                $query = $dbh -> prepare($sql);
                                $query->execute();
                                $results=$query->fetchAll(PDO::FETCH_OBJ);
                                $cnt=1;
                                if($query->rowCount() > 0)
                                {
                                foreach($results as $row)
                                {?>
                                <h5 class="card-title"><?php  echo htmlentities($row->PackageName);?></h5>
                                <p class="card-text"><?php  echo htmlentities($row->Details);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->ShootTime);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->SelectionTime);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->BackdropChoice);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->PrintedPhoto);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->Copies);?></p>
                                <br>
                                <br>
                            <?php $cnt=$cnt+1;}}?>
                            </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card">
                            <div class="card-body">
                            <?php
                                $sql="SELECT * from tblpackages where ID='5'";
                                $query = $dbh -> prepare($sql);
                                $query->execute();
                                $results=$query->fetchAll(PDO::FETCH_OBJ);
                                $cnt=1;
                                if($query->rowCount() > 0)
                                {
                                foreach($results as $row)
                                {?>
                                <h5 class="card-title"><?php  echo htmlentities($row->PackageName);?></h5>
                                <p class="card-text"><?php  echo htmlentities($row->Details);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->ShootTime);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->SelectionTime);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->BackdropChoice);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->PrintedPhoto);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->Copies);?></p>
                                <br>
                                <br>
                            <?php $cnt=$cnt+1;}}?>
                            </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card">
                            <div class="card-body">
                            <?php
                                $sql="SELECT * from tblpackages where ID='6'";
                                $query = $dbh -> prepare($sql);
                                $query->execute();
                                $results=$query->fetchAll(PDO::FETCH_OBJ);
                                $cnt=1;
                                if($query->rowCount() > 0)
                                {
                                foreach($results as $row)
                                {?>
                                <h5 class="card-title"><?php  echo htmlentities($row->PackageName);?></h5>
                                <p class="card-text"><?php  echo htmlentities($row->Details);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->ShootTime);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->SelectionTime);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->BackdropChoice);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->PrintedPhoto);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->Copies);?></p>
                                <br>
                                <br>
                            <?php $cnt=$cnt+1;}}?>
                            </div>
                            </div>
                        </div>
                        <div class="col">
                            <div class="card">
                            <div class="card-body">
                            <?php
                                $sql="SELECT * from tblpackages where ID='7'";
                                $query = $dbh -> prepare($sql);
                                $query->execute();
                                $results=$query->fetchAll(PDO::FETCH_OBJ);
                                $cnt=1;
                                if($query->rowCount() > 0)
                                {
                                foreach($results as $row)
                                {?>
                                <h5 class="card-title"><?php  echo htmlentities($row->PackageName);?></h5>
                                <p class="card-text"><?php  echo htmlentities($row->Details);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->ShootTime);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->SelectionTime);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->BackdropChoice);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->PrintedPhoto);?></p>
                                <p class="card-text"><?php  echo htmlentities($row->Copies);?></p>
                                <br>
                                <br>
                            <?php $cnt=$cnt+1;}}?>
                            </div>
                            </div>
                        </div>
                    </div>
                </div> 
            </section>
            <section class="section-padding" id="booking">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-12 mx-auto">
                            <div class="booking-form">
                                <h2 class="text-center mb-lg-3 mb-2">Book an appointment</h2>
                                <form role="form" method="post" class="needs-validation" novalidate>
                                    <div class="row">
										<div class="col-lg-6 col-12">
                                            <select name="branch" id="branch" class="form-control" required>
                                            <option value="">Select Branch</option>
                                            <!--- Fetching States--->
                                            <?php
                                                $sql="SELECT * FROM tblbranch";
                                                $stmt=$dbh->query($sql);
                                                $stmt->setFetchMode(PDO::FETCH_ASSOC);
                                                while($row =$stmt->fetch()) {
                                                    ?>
                                                <option value="<?php echo $row['ID'];?>"><?php echo $row['BranchName'];?></option>
                                                <?php }?>
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select a valid branch.
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-12">
                                            <input type="text" name="name" id="name" class="form-control" placeholder="Full name" required='true'>
                                            <div class="invalid-feedback">
                                                Please input a valid name.
                                            </div>                                            
                                        </div>

                                        <div class="col-lg-6 col-12">
                                            <input type="email" name="email" id="email" pattern="[^ @]*@[^ @]*" class="form-control" placeholder="Email address" required='true'>
                                            <div class="invalid-feedback">
                                                Please input a valid email address.
                                            </div>
                                        </div>
                                   
                                        <div class="col-lg-6 col-12">
                                            <input type="telephone" name="phone" id="phone" class="form-control" placeholder="Enter Phone Number" maxlength="11" required>
                                            <div class="invalid-feedback">
                                                Please input a valid phone number.
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-12">
                                            <input type="date" name="date" id="date" class="form-control" onchange="sendValue()" required>
                                            <div class="invalid-feedback">
                                                Please select a valid date.
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-12">
                                            <select name="time" id="time" class="form-control" required>
                                            <option value="" id="time1">Select Time</option>
                                            <!--- Fetching States--->
                                            <?php
                                            //create loop to get date today yyyymmdd+timeid and use it as ID for option
                                                
                                                 $sql= "SELECT a.*, b.* FROM tbltime a LEFT JOIN tblappointment b ON a.ID1 = b.AppointmentTime WHERE b.AppointmentTime IS NULL";
                                                //$sql= "SELECT tbltime.*, tbltime.* FROM tbltime RIGHT JOIN tblappointment ON tbltime.TimeStamp_ID != tblappointment.AppointmentNumber";
                                                $stmt=$dbh->query($sql);
                                                $stmt->setFetchMode(PDO::FETCH_ASSOC);
                                                while($row =$stmt->fetch()) {
                                                    ?>
                                                <option value="<?php echo $row['ID1'];?>"><?php echo $row['Time'];?></option>
                                                <?php }?>
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select a valid time.
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-12">
                                            <select name="packages" id="packages" class="form-control" required>
                                            <option value="">Select Packages</option>
                                            <!--- Fetching States--->
                                            <?php
                                                $sql="SELECT * FROM tblpackages";
                                                $stmt=$dbh->query($sql);
                                                $stmt->setFetchMode(PDO::FETCH_ASSOC);
                                                while($row =$stmt->fetch()) {
                                                    ?>
                                                <option value="<?php echo $row['ID'];?>"><?php echo $row['PackageName'];?></option>
                                                <?php }?>
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select a valid package.
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-12">
                                            <select name="payment" id="payment" class="form-control" required>
                                            <option value="">Select Payment Method</option>
                                            <option value="GCash">GCash</option>
                                            <option value="Cash">Cash</option>
                                            </select>
                                            <div class="invalid-feedback">
                                                Please select a valid payment method.
                                            </div>
                                        </div>
 
                                        <div class="col-lg-3 col-md-4 col-6 mx-auto">
                                            <button type="submit" class="form-control" name="submit-button" id="submit-button" data-bs-toggle="modal" data-bs-target="#exampleModal">Book Now</button>
                                        </div>

                                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Book Now</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                <div class="modal-body">
                                                <form role="form" method="post">
                                                <div class="mb-3"><h5>Are you sure all your details are correct?</h5></div>
                                                    <p style="padding-top: 10px">

                                                        <div class="form-check">
                                                            <input class="form-check-input" type="checkbox" value="" id="check" required>
                                                            <label class="form-check-label" for="check">
                                                                <a href="studio-policy.php" class="mb-2">Do you agree in our Studio Policies?</a>
                                                            </label>
                                                        <div class="invalid-feedback">
                                                            Please check the checkbox.
                                                        </div>
                                                        </div>
                                                    </p>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary" name="submit-button1" id="submit-button1">Book Now</button>
                                                </div>
                                                </form>
                                                </div>
                                            </div>
                                        </div>             
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>  
        </main>

        <!-- Footer -->
        <?php include_once('includes/footer.php');?>

        <!-- JAVASCRIPT FILES -->
        <script src="js/jquery.min.js"></script>
        <script src="js/time.js"></script>
        <script src="js/checkbox.js"></script>
        <script src="js/selecteddate.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/scrollspy.min.js"></script>
        <script src="js/custom.js"></script>
        <script src="js/validation.js"></script>
    </body>
</html>