<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['damsid']==0)) {
    header('location:logout.php');
    } else{
    }
?>
<!doctype html>
<html lang="en">
    <head>
        <title>PRIMAX SELF PHOTO STUDIO</title>
        <!-- CSS FILES -->        
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/bootstrap-icons.css" rel="stylesheet">
        <link href="css/owl.carousel.min.css" rel="stylesheet">
        <link href="css/owl.theme.default.min.css" rel="stylesheet">
        <link href="css/templatemo-medic-care.css" rel="stylesheet">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    </head> 
    <body id="top">
        <main>
            <?php include_once('includes/header.php');?>
            <section class="section-padding" id="policy">
                <div class="container">
                        <div class="col-lg-12 col-md-6 col-12">
                            <h2 class="mb-lg-3 mb-3">Studio Policy</h2>
                            <p>
                                <div><font face=\"arial, sans-serif\" size="3px">
                                    <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;At Primax Self Photo Studio, we strive to provide a comfortable and professional environment for all our clients.
                                        To ensure a positive and enjoyable experience for everyone, we have established the following studio policy:
                                    </b></font>
                                </div>
                            </p>
                        </div>
                        <hr />
                        <div class="col-lg-12 col-md-6 col-12">
                            <h5 class="mb-lg-3 mb-3">Studio Hours</h5>
                            <p>
                                <div><font face=\"arial, sans-serif\" size="3px">
                                    <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Our studio operates during regular business hours, depending on the branches. Please check our website or 
                                        contact us for specific operating hours, as they may vary.
                                    </b></font>
                                </div>
                            </p>
                        </div>
                        <hr />
                        <div class="col-lg-12 col-md-6 col-12">
                            <h5 class="mb-lg-3 mb-3">Booking</h5>
                            <p>
                                <div><font face=\"arial, sans-serif\" size="3px">
                                    <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- All studio sessions must be booked in advance. Walk-ins are not guaranteed availability. 
                                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- To secure your booking, a non-refundable deposit may be required, the amount of which will be specified at the time of booking. 
                                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Bookings can be made online or by contacting our studio directly.
                                    </b></font>
                                </div>
                            </p>
                        </div>
                        <hr />
                        <div class="col-lg-12 col-md-6 col-12">
                            <h5 class="mb-lg-3 mb-3">Cancellation and Rescheduling</h5>
                            <p>
                                <div><font face=\"arial, sans-serif\" size="3px">
                                    <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- We understand that circumstances may change. If you need to cancel or reschedule your appointment, please provide at least a day of notice before the scheduled appointment. You can contact us through our provided contact number.
                                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- You can only cancel or reschedule your appointment once to avoid disruptions on other appointments.
                                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Deposits for canceled sessions will not be refunded but can be applied to future booking.
                                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- No-shows within a week will result in the loss of the deposit, and further sessions may require full payment.
                                    </b></font>
                                </div>
                            </p>
                        </div>
                        <hr />
                        <div class="col-lg-12 col-md-6 col-12">
                            <h5 class="mb-lg-3 mb-3">Studio Usage</h5>
                            <p>
                                <div><font face=\"arial, sans-serif\" size="3px">
                                    <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- The studio is for photography purposes only. Any other activities or uses must be approved by management in advance.
                                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Clients are responsible for their personal belongings. Primax Self-Photo Studio is not liable for lost or stolen items.
                                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Children under the age of 6 must be supervised by an adult at all times.
                                    </b></font>
                                </div>
                            </p>
                        </div>
                        <hr />
                        <div class="col-lg-12 col-md-6 col-12">
                            <h5 class="mb-lg-3 mb-3">Studio Equipment</h5>
                            <p>
                                <div><font face=\"arial, sans-serif\" size="3px">
                                    <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Handle all studio equipment with care. Any damage caused due to negligence or misuse will result in additional charges.
                                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Please return all equipment, props, and furniture to their original positions after use.
                                    </b></font>
                                </div>
                            </p>
                        </div>
                        <hr />
                        <div class="col-lg-12 col-md-6 col-12">
                            <h5 class="mb-lg-3 mb-3">Props and Backdrops</h5>
                            <p>
                                <div><font face=\"arial, sans-serif\" size="3px">
                                    <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Clients are responsible for any damage to or loss of studio props and backdrops during their session.
                                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Clients must seek approval for any props or backdrops brought from outside the studio.
                                    </b></font>
                                </div>
                            </p>
                        </div>
                        <hr />
                        <div class="col-lg-12 col-md-6 col-12">
                            <h5 class="mb-lg-3 mb-3">Safety and Conduct</h5>
                            <p>
                                <div><font face=\"arial, sans-serif\" size="3px">
                                    <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- We prioritize the safety and comfort of all clients and staff. Any behavior deemed inappropriate or unsafe will result in immediate removal from the studio without a refund.
                                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Smoking, alcohol, and illegal substances are strictly prohibited within the studio premises.
                                    </b></font>
                                </div>
                            </p>
                        </div>
                        <hr />
                        <div class="col-lg-12 col-md-6 col-12">
                            <h5 class="mb-lg-3 mb-3">Image Usage</h5>
                            <p>
                                <div><font face=\"arial, sans-serif\" size="3px">
                                    <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Primax Self Photo Studio may request to use client images for promotional purposes. Clients will be asked for their consent in such cases.
                                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Client images will not be shared or used for any purpose without explicit consent.
                                    </b></font>
                                </div>
                            </p>
                        </div>
                        <hr />
                        <div class="col-lg-12 col-md-6 col-12">
                            <h5 class="mb-lg-3 mb-3">Payment</h5>
                            <p>
                                <div><font face=\"arial, sans-serif\" size="3px">
                                    <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Payment for studio sessions and additional services is due in full at the end of the session.
                                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- If you want to pay before studio sessions, make sure that it is full so that studio staff will approve your appointment.
                                    </b></font>
                                </div>
                            </p>
                        </div>
                        <hr />
                        <div class="col-lg-12 col-md-6 col-12">
                            <h5 class="mb-lg-3 mb-3">Privacy</h5>
                            <p>
                                <div><font face=\"arial, sans-serif\" size="3px">
                                    <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- We respect your privacy and will protect any personal information provided in accordance with our Privacy Policy.
                                    </b></font>
                                </div>
                            </p>
                        </div>
                        <hr />
                        <div class="col-lg-12 col-md-6 col-12">
                            <p>
                                <div><font face=\"arial, sans-serif\" size="3px">
                                    <b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Please be aware that violation of this policy may result in additional charges, denial of access to the studio, or further action as deemed necessary. 
                                        Through booking a session at Primax Self-Photo Studio, you agree to abide by these policies. We appreciate your understanding and cooperation in maintaining a pleasant and professional environment 
                                        for all clients and staff. If you have any questions or concerns, please do not hesitate to contact us.
                                        <br>
                                        <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;This policy is subject to change, and clients are encouraged to review it periodically for updates. Last updated on October 22, 2023.
                                    </b></font>
                                </div>
                            </p>
                        </div>
                </section>
        </main>
        <?php include_once('includes/footer.php');?>
        <!-- JAVASCRIPT FILES -->
        <script src="js/jquery.min.js"></script>
        <script src="js/time.js"></script>
        <script src="js/bootstrap.bundle.min.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/scrollspy.min.js"></script>
        <script src="js/custom.js"></script>
    </body>
</html>