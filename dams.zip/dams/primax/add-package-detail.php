<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['damsid']==0)) {
  header('location:logout.php');
  } else{

if(isset($_POST['submit']))
{ 
$packagename=$_POST['packagename'];
$details=$_POST['details'];
$shoottime=$_POST['shoottime'];
$selectiontime=$_POST['selectiontime'];
$backdropchoice=$_POST['backdropchoice'];
$printed=$_POST['printed'];
$copy=$_POST['copy'];
$act=$_POST['act'];
  $sql= "insert into tblpackages(PackageName,Details,ShootTime,SelectionTime,BackdropChoice,PrintedPhoto,Copies,AccumulatedTime)values(:packagename,:details,:shoottime,:selectiontime,:backdropchoice,:printed,:copy,:act)";
  $query=$dbh->prepare($sql);
  $query->bindParam(':packagename',$packagename,PDO::PARAM_STR);
  $query->bindParam(':details',$details,PDO::PARAM_STR);
  $query->bindParam(':shoottime',$shoottime,PDO::PARAM_STR);
  $query->bindParam(':selectiontime',$selectiontime,PDO::PARAM_STR);
  $query->bindParam(':backdropchoice',$backdropchoice,PDO::PARAM_STR);
  $query->bindParam(':printed',$printed,PDO::PARAM_STR);
  $query->bindParam(':copy',$copy,PDO::PARAM_STR);
  $query->bindParam(':act',$act,PDO::PARAM_STR);
  $query->execute();
  echo '<script>alert("Data has been Inserted")</script>';
  echo "<script>window.location.href ='all-package-list.php'</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <title>PRIMAX || View Appointment Detail</title>
	
<link rel="stylesheet" href="libs/bower/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="libs/bower/material-design-iconic-font/dist/css/material-design-iconic-font.css">
<!-- build:css assets/css/app.min.css -->
<link rel="stylesheet" href="libs/bower/animate.css/animate.min.css">
<link rel="stylesheet" href="libs/bower/fullcalendar/dist/fullcalendar.min.css">
<link rel="stylesheet" href="libs/bower/perfect-scrollbar/css/perfect-scrollbar.css">
<link rel="stylesheet" href="assets/css/bootstrap.css">
<link rel="stylesheet" href="assets/css/core.css">
<link rel="stylesheet" href="assets/css/app.css">
<!-- endbuild -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,300">
<script src="libs/bower/breakpoints.js/dist/breakpoints.min.js"></script>
<script>
	Breakpoints();
</script>	
</head>
<body class="menubar-left menubar-unfold menubar-light theme-primary">
<!--============= start main area -->
<?php include_once('includes/header.php');?>
<?php include_once('includes/sidebar.php');?>
<!-- APP MAIN ==========-->
<main id="app-main" class="app-main">
  <div class="wrap">
	<section class="app-content">
		<div class="row">
			<!-- DOM dataTable -->
			<div class="col-md-12">
				<div class="widget">
					<header class="widget-header">
						<h4 class="widget-title" style="color: blue">Add Package</h4>
					</header><!-- .widget-header -->
					<hr class="widget-separator">
					<div class="widget-body">
						<div class="table-responsive">
              <form method="post" name="submit">
	            <table border="1" class="table table-bordered mg-b-0">
                <tr>
                                  <th>Package Name</th>
                                  <td>
                                  <input type="text" name="packagename" id="packagename" class="form-control" placeholder="Package Name" required='true'>
                                  </td>
                                  <th>Details</th>
                                  <td>
                                  <input type="text" name="details" id="details" class="form-control" placeholder="Details" required='true'>
                                  </td>
                                </tr> 
     
                                <tr>
                                  <th>Photoshoot Time</th>
                                  <td>
                                  <input type="text" name="shoottime" id="shoottime" class="form-control" placeholder="Photoshoot Time" required='true'>                                  
                                  </td>
                                  <th>Photo Selection Time</th>
                                  <td>
                                  <input type="text" name="selectiontime" id="selectiontime" class="form-control" placeholder="Photo Selection Time" required='true'>
                                  </td>
                                </tr>

                                <tr>
                                  <th>Backdrop Choice</th>
                                  <td>
                                  <input type="text" name="backdropchoice" id="backdropchoice" class="form-control" placeholder="Backdrop Choice" required='true'>
                                  </td>
                                  <th>Printed Photo</th>
                                  <td>
                                  <input type="text" name="printed" id="printed" class="form-control" placeholder="Printed Photo" required='true'>
                                  </td>
                                </tr>

                                <tr>
                                  <th>Copies</th>
                                  <td>
                                  <input type="text" name="copy" id="copy" class="form-control" placeholder="Copies" required='true'>
                                  </td>
                                  <th>Accumulated Time</th>
                                  <td>
                                  <input type="text" name="act" id="act" class="form-control" placeholder="Accumulated Time" required='true'>
                                  </td>
                                </tr>
              </table> 
              <br>
                  <p align="center"  style="padding-top: 20px">                            
                    <button class="btn btn-primary waves-effect waves-light w-lg" type="submit" name="submit">Add</button></p>
              </form>                   
            </div>
          </div><!-- .widget-body -->	
        </div><!-- .widget -->
      </div><!-- END column -->
    </div><!-- .row -->
  </section><!-- .app-content -->
</div><!-- .wrap -->
<!-- APP FOOTER -->
<?php include_once('includes/footer.php');?>
<!-- /#app-footer -->
</main>
<!--========== END app main -->

<!-- APP CUSTOMIZER -->
<?php include_once('includes/customizer.php');?>

	
<!-- build:js assets/js/core.min.js -->
<script src="libs/bower/jquery/dist/jquery.js"></script>
<script src="libs/bower/jquery-ui/jquery-ui.min.js"></script>
<script src="libs/bower/jQuery-Storage-API/jquery.storageapi.min.js"></script>
<script src="libs/bower/bootstrap-sass/assets/javascripts/bootstrap.js"></script>
<script src="libs/bower/jquery-slimscroll/jquery.slimscroll.js"></script>
<script src="libs/bower/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>
<script src="libs/bower/PACE/pace.min.js"></script>
<!-- endbuild -->

<!-- build:js assets/js/app.min.js -->
<script src="assets/js/library.js"></script>
<script src="assets/js/plugins.js"></script>
<script src="assets/js/app.js"></script>
<!-- endbuild -->
<script src="libs/bower/moment/moment.js"></script>
<script src="libs/bower/fullcalendar/dist/fullcalendar.min.js"></script>
<script src="assets/js/fullcalendar.js"></script>
</body>
</html>
<?php }  ?>