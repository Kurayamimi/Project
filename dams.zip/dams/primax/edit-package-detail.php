<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['damsid']==0)) {
  header('location:logout.php');
  } else{

 if(isset($_POST['submit']))
  { 
    $edit=$_GET['edit'];
    $pid=$_GET['pid'];
    $packagename=$_POST['packagename'];
    $details=$_POST['details'];
    $shoottime=$_POST['shoottime'];
    $selectiontime=$_POST['selectiontime'];
    $backdropchoice=$_POST['backdropchoice'];
    $printed=$_POST['printed'];
    $copy=$_POST['copy'];
    $act=$_POST['act'];
    $sql= "update tblpackages set PackageName=:packagename,Details=:details,ShootTime=:shoottime,SelectionTime=:selectiontime,BackdropChoice=:backdropchoice,PrintedPhoto=:printed,Copies=:copy,AccumulatedTime=:act where ID=:edit";
    $query=$dbh->prepare($sql);
$query->bindParam(':packagename',$packagename,PDO::PARAM_STR);
$query->bindParam(':details',$details,PDO::PARAM_STR);
$query->bindParam(':shoottime',$shoottime,PDO::PARAM_STR);
$query->bindParam(':selectiontime',$selectiontime,PDO::PARAM_STR);
$query->bindParam(':backdropchoice',$backdropchoice,PDO::PARAM_STR);
$query->bindParam(':printed',$printed,PDO::PARAM_STR);
$query->bindParam(':copy',$copy,PDO::PARAM_STR);
$query->bindParam(':act',$act,PDO::PARAM_STR);
$query->bindParam(':edit',$edit,PDO::PARAM_STR);
 $query->execute();
 echo '<script>alert("Data successfully updated")</script>';
 echo "<script>window.location.href ='all-package-list.php'</script>";
}
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
	
	<title>PRIMAX|| Edit Package Detail</title>
	
	<link rel="stylesheet" href="libs/bower/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="libs/bower/material-design-iconic-font/dist/css/material-design-iconic-font.css">
	<!-- build:css assets/css/app.min.css -->
	<link rel="stylesheet" href="libs/bower/animate.css/animate.min.css">
	<link rel="stylesheet" href="libs/bower/fullcalendar/dist/fullcalendar.min.css">
	<link rel="stylesheet" href="libs/bower/perfect-scrollbar/css/perfect-scrollbar.css">
	<link rel="stylesheet" href="assets/css/bootstrap.css">
	<link rel="stylesheet" href="assets/css/core.css">
	<link rel="stylesheet" href="assets/css/app.css">
	<!-- endbuild -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900,300">
	<script src="libs/bower/breakpoints.js/dist/breakpoints.min.js"></script>
	<script>
		Breakpoints();
	</script>
	
</head>
	
<body class="menubar-left menubar-unfold menubar-light theme-primary">
<!--============= start main area -->



<?php include_once('includes/header.php');?>

<?php include_once('includes/sidebar.php');?>



<!-- APP MAIN ==========-->
<main id="app-main" class="app-main">
  <div class="wrap">
	<section class="app-content">
		<div class="row">
			<!-- DOM dataTable -->
			<div class="col-md-12">
				<div class="widget">
					<header class="widget-header">
						<h4 class="widget-title" style="color: blue">Package Details</h4>
					</header><!-- .widget-header -->
					<hr class="widget-separator">
					<div class="widget-body">
						<div class="table-responsive">
							<?php
                $edit=$_GET['edit'];
                $sql="SELECT * from tblpackages  where ID=:edit";
                $query = $dbh -> prepare($sql);
                $query-> bindParam(':edit', $edit, PDO::PARAM_STR);
                $query->execute();
                $results=$query->fetchAll(PDO::FETCH_OBJ);

                $cnt=1;
                if($query->rowCount() > 0)
                {
                foreach($results as $row)
                {               ?>
							    <table border="1" class="table table-bordered mg-b-0">
                    <tr>
                      <th>PackageName</th>
                      <td><?php  echo $row->PackageName;?></td>
                      <th>Details</th>
                      <td><?php  echo $row->Details;?></td>
                    </tr>

                    <tr>
                      <th>Photoshoot Time</th>
                      <td><?php  echo $row->ShootTime;?></td>
                      <th>Photo Selection Time</th>
                      <td><?php  echo $row->SelectionTime;?></td>
                    </tr>
                    <tr>
                      <th>Backdrop Choice</th>
                      <td><?php  echo $row->BackdropChoice;?></td>
                      <th>Printed Photo</th>
                      <td><?php  echo $row->PrintedPhoto;?></td>
                    </tr>
   
                    <tr>
                      <th>Copies</th>
                      <td><?php  echo $row->Copies;?></td>
                      <th>Accumulated Time</th>
                      <td><?php  echo $row->AccumulatedTime;?></td>
                    </tr>
 
                  <?php $cnt=$cnt+1;}} ?>
                  </table> 
                  <br>

                  <p align="center"  style="padding-top: 20px">                            
                    <button class="btn btn-primary waves-effect waves-light w-lg" data-toggle="modal" data-target="#myModal">Update Package</button></p>  
                    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                            <h5 class="modal-title" id="exampleModalLabel">Update Package</h5>
                          </div>
                          <div class="modal-body">
                            <table class="table table-bordered table-hover data-tables">
                              <form method="post" name="submit">

                                <tr>
                                  <th>Package Name</th>
                                  <td>
                                  <textarea name="packagename" placeholder="Package Name" rows="12" cols="14" class="form-control wd-450" required="true"></textarea>
                                  </td>
                                  <th>Details</th>
                                  <td>
                                  <textarea name="details" placeholder="Details" rows="12" cols="14" class="form-control wd-450" required="true"></textarea>
                                  </td>
                                </tr> 
     
                                <tr>
                                  <th>Photoshoot Time</th>
                                  <td>
                                  <textarea name="shoottime" placeholder="Photoshoot Time" rows="12" cols="14" class="form-control wd-450" required="true"></textarea>
                                  </td>
                                  <th>Photo Selection Time</th>
                                  <td>
                                  <textarea name="selectiontime" placeholder="Photo Selection Time" rows="12" cols="14" class="form-control wd-450" required="true"></textarea>
                                  </td>
                                </tr>

                                <tr>
                                  <th>Backdrop Choice</th>
                                  <td>
                                  <textarea name="backdropchoice" placeholder="Backdrop" rows="12" cols="14" class="form-control wd-450" required="true"></textarea>
                                  </td>
                                  <th>Printed Photo</th>
                                  <td>
                                  <textarea name="printed" placeholder="Printed Photo" rows="12" cols="14" class="form-control wd-450" required="true"></textarea>
                                  </td>
                                </tr>

                                <tr>
                                  <th>Copies</th>
                                  <td>
                                  <textarea name="copy" placeholder="Copies" rows="12" cols="14" class="form-control wd-450" required="true"></textarea>
                                  </td>
                                  <th>Accumulated Time</th>
                                  <td>
                                  <textarea name="act" placeholder="Accumulated Time" rows="12" cols="14" class="form-control wd-450" required="true"></textarea>
                                  </td>
                                </tr>
                            </table>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" name="submit" class="btn btn-primary">Update</button>
                        </form>
                        </div>    
                      </div>
                    </div>
						</div>
					</div><!-- .widget-body -->
					
   
				</div><!-- .widget -->
			</div><!-- END column -->
			
			
		</div><!-- .row -->
	</section><!-- .app-content -->
</div><!-- .wrap -->
  <!-- APP FOOTER -->
  <?php include_once('includes/footer.php');?>
  <!-- /#app-footer -->
</main>
<!--========== END app main -->

	<!-- APP CUSTOMIZER -->
<?php include_once('includes/customizer.php');?>

	
		<!-- build:js assets/js/core.min.js -->
	<script src="libs/bower/jquery/dist/jquery.js"></script>
	<script src="libs/bower/jquery-ui/jquery-ui.min.js"></script>
	<script src="libs/bower/jQuery-Storage-API/jquery.storageapi.min.js"></script>
	<script src="libs/bower/bootstrap-sass/assets/javascripts/bootstrap.js"></script>
	<script src="libs/bower/jquery-slimscroll/jquery.slimscroll.js"></script>
	<script src="libs/bower/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>
	<script src="libs/bower/PACE/pace.min.js"></script>
	<!-- endbuild -->

	<!-- build:js assets/js/app.min.js -->
	<script src="assets/js/library.js"></script>
	<script src="assets/js/plugins.js"></script>
	<script src="assets/js/app.js"></script>
	<!-- endbuild -->
	<script src="libs/bower/moment/moment.js"></script>
	<script src="libs/bower/fullcalendar/dist/fullcalendar.min.js"></script>
	<script src="assets/js/fullcalendar.js"></script>
</body>
</html>
<?php }  ?>