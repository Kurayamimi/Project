<div class="wrap p-t-0">
    <footer class="app-footer">
      
        <div class="copyright pull-left">PRIMAX Self Photo Studio </div>
   
    </footer>
</div>