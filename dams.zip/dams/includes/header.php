<nav class="navbar navbar-expand-lg bg-light fixed-top shadow-lg">
                <div class="container">
                    <a class="navbar-brand mx-auto d-lg-none" href="index.php" style="color:black">
                        PRIMAX
                        <strong class="d-block">Self-Photo Studio</strong>
                    </a>

                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav mx-auto">
                            <li class="nav-item active">
                                <a class="nav-link" href="index.php">Home</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="index.php #about">About Us</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="index.php #contact">Contact</a>
                            </li>

                            <a class="navbar-brand d-none d-lg-block" href="index.php" style="color: black">
                            PRIMAX
                                <strong class="d-block">Self-Photo Studio</strong>
                            </a>

                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    General
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <li><h6 class="dropdown-header">General</h6></li>
                                    <li><a class="dropdown-item" href="studio-policy.php">Studio Policy</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><h6 class="dropdown-header">Features</h6></li>
                                    <li><a class="dropdown-item" href="check-appointment.php">Check Appointment</a></li>
                                    <li><a class="dropdown-item" href="location.php">Location</a></li>
                                </ul>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="index.php #booking">Booking</a>
                            </li>

                        </ul>
                    </div>

                </div>
            </nav>